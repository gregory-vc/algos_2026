package t1.algos;

class LinkedList<T> {
    private Element<T> first;
    private Element<T> last;
    private int size = 0;

    private static class Element<T> implements Node<T> {
        T value;
        Element<T> next;
        Element<T> prev;

        Element(T value) {
            this.value = value;
        }

        @Override
        public T getValue() {
            return value;
        }
    }

    public Node<T> addFirst(T value) {
        Element<T> newElement = new Element<>(value);
        newElement.next = first;
        if (first != null) {
            first.prev = newElement;
        }
        first = newElement;
        if (last == null) {
            last = newElement;
        }
        size++;
        return newElement;
    }

    public Node<T> addLast(T value) {
        Element<T> newElement = new Element<>(value);
        newElement.prev = last;
        if (last != null) {
            last.next = newElement;
        }
        last = newElement;
        if (first == null) {
            first = newElement;
        }
        size++;
        return newElement;
    }

    public Node<T> insertAfter(Node<T> node, T value) {
        Element<T> current = (Element<T>) node;
        Element<T> newElement = new Element<>(value);

        newElement.next = current.next;
        newElement.prev = current;

        if (current.next != null) {
            current.next.prev = newElement;
        }
        current.next = newElement;
        if (current == last) {
            last = newElement;
        }

        size++;
        return newElement;
    }

    public boolean contains(T value) {
        return indexOf(value) != -1;
    }

    public int indexOf(T value) {
        Element<T> current = first;
        int index = 0;

        while (current != null) {
            if (current.value.equals(value)) {
                return index;
            }
            current = current.next;
            index++;
        }

        return -1;
    }

    public void removeFirst() {
        if (first == null) return;
        first = first.next;
        if (first != null) {
            first.prev = null;
        } else {
            last = null;
        }
        size--;
    }

    public void removeLast() {
        if (last == null) return;
        last = last.prev;
        if (last != null) {
            last.next = null;
        } else {
            first = null;
        }
        size--;
    }

    public void remove(Node<T> node) {
        Element<T> element = (Element<T>) node;

        if (element == first) {
            removeFirst();
            return;
        }

        if (element == last) {
            removeLast();
            return;
        }

        element.prev.next = element.next;
        element.next.prev = element.prev;

        size--;
    }

    public void set(Node<T> node, T value) {
        Element<T> element = (Element<T>) node;
        element.value = value;
    }
}
