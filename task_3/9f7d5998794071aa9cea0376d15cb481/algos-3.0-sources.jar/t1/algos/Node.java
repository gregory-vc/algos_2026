package t1.algos;

interface Node<T> {
    T getValue();
}
