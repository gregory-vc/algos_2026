package t1.algos;

public record Result(int min, int max) {
}
