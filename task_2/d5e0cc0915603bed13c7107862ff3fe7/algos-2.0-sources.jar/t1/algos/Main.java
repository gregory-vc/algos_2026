package t1.algos;


import java.math.BigInteger;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Integer> lst= List.of(1,2,3,4,5);
        System.out.println("Example of finding min max for List " + lst );
        System.out.println(Solution.findMinMax(lst));
    }
}

