package t1.algos;

import java.util.List;

public class Solution {

    public static Result findMinMax(List<Integer> lst) {
        if (lst == null || lst.isEmpty()) {
            throw new IllegalArgumentException("List is empty");
        }

        int min = lst.get(0);
        int max = lst.get(0);

        for (int i = 1; i < lst.size(); i++) {
            if (min > lst.get(i)) min = lst.get(i);
            if (max < lst.get(i)) max = lst.get(i);
        }

        return new Result(min, max);
    }

    public static Result findMinMaxCompact(List<Integer> lst) {
        if (lst == null || lst.isEmpty()) {
            throw new IllegalArgumentException("List is empty");
        }

        int n = lst.size();

        int min = lst.get(0);
        int max = lst.get(0);
        int i = 1;

        if (n % 2 == 0) {
            if (lst.get(0) < lst.get(1)) {
                min = lst.get(0);
                max = lst.get(1);
            } else {
                min = lst.get(1);
                max = lst.get(0);
            }
            i = 2;
        }


        while (i < n - 1) {
            int localMin = lst.get(i);
            int localMax = lst.get(i + 1);

            if (localMin > localMax){
                localMin = lst.get(i + 1);
                localMax = lst.get(i);
            }

            if (localMin < min) {
                min = localMin;
            }
            if (localMax > max) {
                max = localMax;
            }

            i += 2;
        }

        return new Result(min, max);
    }
}
