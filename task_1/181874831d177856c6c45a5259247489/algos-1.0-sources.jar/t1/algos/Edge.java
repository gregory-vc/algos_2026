package t1.algos;

public class Edge {
    int speed; //пропускная способность в МБ
    double loss; // потери (0.9 = 90%)
    Node target;// куда ведет ребро

    public Edge(Node target, int speed, double loss) {
        this.speed = speed;
        this.loss = loss;
        this.target = target;
    }

    @Override
    public String toString() {
        return target.name + "(" + speed + ", " + (int) (loss * 100) + "%)";
    }
}
