package t1.algos;

import java.util.*;
import static t1.algos.Solution.matrixNet;
import static t1.algos.Solution.nodeNet;

public class Main {
    public static void main(String[] args) {
        System.out.println("Визуализация представления графа");
        System.out.println("\n\nСпособ 1. Массив:");
        Value[][] net= matrixNet();
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                System.out.printf("%-12s", net[i][j] != null ? net[i][j] : "[---------]");
            }
            System.out.println();
        }
        System.out.println("\n\nСпособ 2. Узлы:");
        print(nodeNet());
    }
    public static void print(Node node) {
        Set<Node> visited = new HashSet<>();
        dfs(node, visited);
    }

    private static void dfs(Node node, Set<Node> visited) {
        if (node == null || visited.contains(node)) {
            return;
        }
        visited.add(node);
        node.show();
        for (Edge edge : node.friends) {
            dfs(edge.target, visited);
        }
    }


}

