package t1.algos;

public class Solution {
    public static Value[][] matrixNet() {
        Value[][] net = new Value[6][6];
        java.util.function.BiConsumer<int[], double[]> add = (pair, data) -> {
            int a = pair[0], b = pair[1];
            net[a][b] = new Value((int)data[0], data[1]);
            net[b][a] = new Value((int)data[0], data[1]);
        };

        // связи
        add.accept(new int[]{0,1}, new double[]{1500, 0.9});
        add.accept(new int[]{0,2}, new double[]{2000, 0.1});
        add.accept(new int[]{0,3}, new double[]{1000, 0.5});
        add.accept(new int[]{1,4}, new double[]{1500, 0.6});
        add.accept(new int[]{2,4}, new double[]{900,  0.05});
        add.accept(new int[]{2,5}, new double[]{500,  0.2});
        add.accept(new int[]{3,4}, new double[]{2500, 0.01});
        add.accept(new int[]{4,5}, new double[]{300,  0.85});
        return net;
    }

    public static Node nodeNet() {
        // создаём узлы
        Node A = new Node("A");
        Node B = new Node("B");
        Node C = new Node("C");
        Node D = new Node("D");
        Node E = new Node("E");
        Node F = new Node("F");

        // соединяем их
        A.connect(B, 1500, 0.9);
        A.connect(C, 2000, 0.1);
        A.connect(D, 1000, 0.5);
        B.connect(F, 1500, 0.6);
        C.connect(E, 900,  0.05);
        C.connect(F, 500,  0.2);
        D.connect(E, 2500, 0.01);
        E.connect(F, 300,  0.85);

        //возвращаем ссылку на первый
        return A;
    }
}
