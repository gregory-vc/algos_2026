package t1.algos;

public record Value(int speed, double loss) {
    @Override
    public String toString() {
        return "[" + speed + ", " + loss + ']';
    }
}
