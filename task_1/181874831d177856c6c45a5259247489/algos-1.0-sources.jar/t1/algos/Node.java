package t1.algos;

import java.util.ArrayList;
import java.util.List;

public class Node {
    String name;//имя
    List<Edge> friends = new ArrayList<>(); // соседи, с кем связан

    public Node(String name) {
        this.name = name;
    }

    public void connect(Node other, int cap, double loss) {
        friends.add(new Edge(other, cap, loss));
        other.friends.add(new Edge(this, cap, loss)); // двусторонняя связь
    }

    public void show() {
        System.out.print(name + " -> ");
        for (Edge f : friends) {
            System.out.print(f + " | ");
        }
        System.out.println();
    }
}
